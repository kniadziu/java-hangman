package pl.edu.agh.hangman;

import org.junit.Assert;
import org.junit.Test;

public class HangmanTest {
    @Test
    public void testThatTestsNothing() {
        Assert.assertTrue("You need to implement it!", false);
    }
}
